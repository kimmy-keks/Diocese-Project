<?php
include 'db_connection.php'; // your DB connection file

// Handle User Addition
if (isset($_POST['submit'])) {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password
    $user_type = $_POST['user_type'];
    $subsystem_access = $_POST['subsystem_access'];
    
    // Handle photo upload
    $id_photo = '';
    if (isset($_FILES['id_photo']) && $_FILES['id_photo']['error'] == 0) {
        $upload_dir = '../uploads/user_photos/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES['id_photo']['name'], PATHINFO_EXTENSION));
        $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif');
        
        if (in_array($file_extension, $allowed_extensions)) {
            $new_filename = 'user_' . time() . '.' . $file_extension;
            $upload_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['id_photo']['tmp_name'], $upload_path)) {
                $id_photo = 'uploads/user_photos/' . $new_filename;
            }
        }
    }

    // Insert new user with error handling
    $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, username, email, password, user_type, subsystem_access, id_photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("ssssssss", $first_name, $last_name, $username, $email, $password, $user_type, $subsystem_access, $id_photo);
        if ($stmt->execute()) {
            header("Location: manage_users.php");
            exit;
        } else {
            $error = "Error adding user: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $error = "Error preparing statement: " . $conn->error;
    }
}

// Handle Deletion
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: manage_users.php");
    exit;
}

// Handle Update
if (isset($_POST['update_user'])) {
    $id = $_POST['edit_id'];
    $first_name = $_POST['edit_first_name'];
    $last_name = $_POST['edit_last_name'];
    $username = $_POST['edit_username'];
    $email = $_POST['edit_email'];
    $user_type = $_POST['edit_user_type'];
    $subsystem_access = $_POST['edit_subsystem_access'];

    $stmt = $conn->prepare("UPDATE users SET first_name=?, last_name=?, username=?, email=?, user_type=?, subsystem_access=? WHERE id=?");
    $stmt->execute([$first_name, $last_name, $username, $email, $user_type, $subsystem_access, $id]);

    header("Location: manage_users.php");
    exit;
}

// Fetch all users
$stmt = $conn->prepare("SELECT * FROM users");
$stmt->execute();
$result = $stmt->get_result();
$users = [];
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Add Users</title>
    <meta
      content="width=device-width, initial-scale=1.0, shrink-to-fit=no"
      name="viewport"
    />
    <link
      rel="icon"
      href="../system_admin/assets/img/kaiadmin/favicon.ico"
      type="image/x-icon"
    />

    <!-- Fonts and icons -->
    <script src="../system_admin/assets/js/plugin/webfont/webfont.min.js"></script>
    <script>
      WebFont.load({
        google: { families: ["Public Sans:300,400,500,600,700"] },
        custom: {
          families: [
            "Font Awesome 5 Solid",
            "Font Awesome 5 Regular",
            "Font Awesome 5 Brands",
            "simple-line-icons",
          ],
          urls: ["../system_admin/assets/css/fonts.min.css"],
        },
        active: function () {
          sessionStorage.fonts = true;
        },
      });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="../system_admin/assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../system_admin/assets/css/plugins.min.css" />
    <link rel="stylesheet" href="../system_admin/assets/css/kaiadmin.min.css" />
    <link rel="stylesheet" href="../system_admin/assets/css/demo.css" />
  </head>
  <body>
    <div class="wrapper">
      <!-- Sidebar -->
      <div class="sidebar" data-background-color="dark">
        <div class="sidebar-logo">
          <!-- Logo Header -->
          <div class="logo-header" data-background-color="dark">
            <a href="../system_admin/index.html" class="logo">
              <img
                src="../images/logo.png"
                alt="navbar brand"
                class="navbar-brand"
                height="30"
              />
            </a>
            <div class="nav-toggle">
              <button class="btn btn-toggle toggle-sidebar">
                <i class="gg-menu-right"></i>
              </button>
              <button class="btn btn-toggle sidenav-toggler">
                <i class="gg-menu-left"></i>
              </button>
            </div>
            <button class="topbar-toggler more">
              <i class="gg-more-vertical-alt"></i>
            </button>
          </div>
          <!-- End Logo Header -->
        </div>
        <div class="sidebar-wrapper scrollbar scrollbar-inner">
          <div class="sidebar-content">
            <ul class="nav nav-secondary">
              <li class="nav-item">
                <a href="../system_admin/index.php">
                  <i class="fas fa-home"></i>
                  <p>Admin Dashboard</p>
                </a>
              </li>
              <li class="nav-section">
                <span class="sidebar-mini-icon">
                  <i class="fa fa-ellipsis-h"></i>
                </span>
                <h4 class="text-section">Components</h4>
              </li>
              <li class="nav-item">
                <a data-bs-toggle="collapse" href="#forms">
                  <i class="fas fa-pen-square"></i>
                  <p>Forms</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse" id="forms">
                  <ul class="nav nav-collapse">
                    <li>
                      <a href="../system_admin/forms/deaneryinfo.php">
                        <span class="sub-item">Deanery</span>
                      </a>
                    </li>
                    <li>
                      <a href="../system_admin/forms/parishinfo.php">
                        <span class="sub-item">Parish</span>
                      </a>
                    </li>
                    <li>
                      <a href="../system_admin/forms/cpc.php">
                        <span class="sub-item">CPC</span>
                      </a>
                    </li>
                    <li>
                      <a href="../system_admin/forms/lkk.php">
                        <span class="sub-item">LKK</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
              <li class="nav-item">
                <a data-bs-toggle="collapse" href="#tables">
                  <i class="fas fa-table"></i>
                  <p>Records</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse" id="tables">
                  <ul class="nav nav-collapse">
                    <li>
                      <a href="../system_admin/tables/deaneryrecords.php">
                        <span class="sub-item">Deanery Records</span>
                      </a>
                    </li>
                    <li>
                      <a href="../system_admin/tables/parishrecords.php">
                        <span class="sub-item">Parish Records</span>
                      </a>
                    </li>
                    <li>
                      <a href="../system_admin/tables/cpcrecords.php">
                        <span class="sub-item">CPC Records</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
              <li class="nav-item">
                <a data-bs-toggle="collapse" href="#charts">
                  <i class="far fa-chart-bar"></i>
                  <p>Charts</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse" id="charts">
                  <ul class="nav nav-collapse">
                    <li>
                      <a href="../system_admin/charts/parishcharts.php">
                        <span class="sub-item">Parish Charts</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
              <li class="nav-item active">
                <a data-bs-toggle="collapse" href="#users" class="collapsed" aria-expanded="false">
                  <i class="fas fa-users"></i>
                  <p>Users</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse show" id="users">
                  <ul class="nav nav-collapse">
                    <li class="active">
                      <a href="add_users.php">
                        <span class="sub-item">Add User</span>
                      </a>
                    </li>
                    <li>
                      <a href="manage_users.php">
                        <span class="sub-item">Manage Users</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <!-- End Sidebar -->

      <div class="main-panel">
        <div class="main-header">
          <div class="main-header-logo">
            <!-- Logo Header -->
            <div class="logo-header" data-background-color="dark">
              <a href="../system_admin/index.html" class="logo">
                <img
                  src="../system_admin/assets/img/kaiadmin/logo_light.svg"
                  alt="navbar brand"
                  class="navbar-brand"
                  height="20"
                />
              </a>
              <div class="nav-toggle">
                <button class="btn btn-toggle toggle-sidebar">
                  <i class="gg-menu-right"></i>
                </button>
                <button class="btn btn-toggle sidenav-toggler">
                  <i class="gg-menu-left"></i>
                </button>
              </div>
              <button class="topbar-toggler more">
                <i class="gg-more-vertical-alt"></i>
              </button>
            </div>
            <!-- End Logo Header -->
          </div>
          <!-- Navbar Header -->
          <nav class="navbar navbar-header navbar-header-transparent navbar-expand-lg border-bottom">
            <div class="container-fluid">
              <nav class="navbar navbar-header-left navbar-expand-lg navbar-form nav-search p-0 d-none d-lg-flex">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <button type="submit" class="btn btn-search pe-1">
                      <i class="fa fa-search search-icon"></i>
                    </button>
                  </div>
                  <input type="text" placeholder="Search ..." class="form-control" />
                </div>
              </nav>

              <ul class="navbar-nav topbar-nav ms-md-auto align-items-center">
                <li class="nav-item topbar-icon dropdown hidden-caret d-flex d-lg-none">
                  <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false" aria-haspopup="true">
                    <i class="fa fa-search"></i>
                  </a>
                  <ul class="dropdown-menu dropdown-search animated fadeIn">
                    <form class="navbar-left navbar-form nav-search">
                      <div class="input-group">
                        <input type="text" placeholder="Search ..." class="form-control" />
                      </div>
                    </form>
                  </ul>
                </li>
                <li class="nav-item topbar-icon dropdown hidden-caret">
                  <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false" aria-haspopup="true">
                    <i class="fa fa-bell"></i>
                    <span class="notification">4</span>
                  </a>
                  <ul class="dropdown-menu dropdown-notifications animated fadeIn">
                    <li class="dropdown-header">Notifications</li>
                    <li class="dropdown-item">
                      <a href="#">
                        <div class="notification-icon">
                          <i class="fa fa-user"></i>
                        </div>
                        <div class="notification-content">
                          <span class="notification-title">New user registered</span>
                          <span class="notification-time">2 minutes ago</span>
                        </div>
                      </a>
                    </li>
                    <li class="dropdown-item">
                      <a href="#">
                        <div class="notification-icon">
                          <i class="fa fa-bell"></i>
                        </div>
                        <div class="notification-content">
                          <span class="notification-title">New notification</span>
                          <span class="notification-time">1 hour ago</span>
                        </div>
                      </a>
                    </li>
                    <li class="dropdown-footer">
                      <a href="#">View all notifications</a>
                    </li>
                  </ul>
                </li>
                <li class="nav-item topbar-icon dropdown hidden-caret">
                  <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false" aria-haspopup="true">
                    <i class="fa fa-envelope"></i>
                    <span class="notification">3</span>
                  </a>
                  <ul class="dropdown-menu dropdown-messages animated fadeIn">
                    <li class="dropdown-header">Messages</li>
                    <li class="dropdown-item">
                      <a href="#">
                        <div class="message-icon">
                          <i class="fa fa-user"></i>
                        </div>
                        <div class="message-content">
                          <span class="message-title">John Doe</span>
                          <span class="message-time">2 minutes ago</span>
                          <p>Hello, how are you?</p>
                        </div>
                      </a>
                    </li>
                    <li class="dropdown-footer">
                      <a href="#">View all messages</a>
                    </li>
                  </ul>
                </li>
                <li class="nav-item topbar-icon dropdown hidden-caret">
                  <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false" aria-haspopup="true">
                    <i class="fa fa-user"></i>
                  </a>
                  <ul class="dropdown-menu dropdown-user animated fadeIn">
                    <li class="dropdown-header">User</li>
                    <li class="dropdown-item">
                      <a href="#">
                        <i class="fa fa-user"></i> Profile
                      </a>
                    </li>
                    <li class="dropdown-item">
                      <a href="#">
                        <i class="fa fa-cog"></i> Settings
                      </a>
                    </li>
                    <li class="dropdown-divider"></li>
                    <li class="dropdown-item">
                      <a href="#">
                        <i class="fa fa-sign-out-alt"></i> Logout
                      </a>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </nav>
        </div>

        <div class="container">
          <div class="page-inner">
            <div class="page-header">
              <h3 class="fw-bold mb-3">User Management</h3>
              <ul class="breadcrumbs mb-3">
                <li class="nav-home">
                  <a href="#">
                    <i class="icon-home"></i>
                  </a>
                </li>
                <li class="separator">
                  <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                  <a href="#">Users</a>
                </li>
                <li class="separator">
                  <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                  <a href="#">Add User</a>
                </li>
              </ul>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header">
                    <div class="card-title">Add New User</div>
                  </div>
                  <div class="card-body">
                    <?php if (isset($error)): ?>
                      <div class="alert alert-danger">
                        <?php echo htmlspecialchars($error); ?>
                      </div>
                    <?php endif; ?>
                    <form action="" method="POST" enctype="multipart/form-data">
                      <div class="form-group">
                        <label for="first_name">First Name</label>
                        <input type="text" class="form-control" id="first_name" name="first_name" required>
                      </div>
                      <div class="form-group">
                        <label for="last_name">Last Name</label>
                        <input type="text" class="form-control" id="last_name" name="last_name" required>
                      </div>
                      <div class="form-group">
                        <label for="id_photo">ID Photo</label>
                        <input type="file" class="form-control" id="id_photo" name="id_photo" accept="image/*" required>
                        <small class="form-text text-muted">Upload a passport-style photo (max size: 2MB)</small>
                      </div>
                      <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                      </div>
                      <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                      </div>
                      <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                      </div>
                      <div class="form-group">
                        <label for="user_type">User Type</label>
                        <select class="form-control" id="user_type" name="user_type" required>
                          <option value="">Select User Type</option>
                          <option value="Admin">Admin</option>
                          <option value="Parish Priest">Parish Priest</option>
                          <option value="Teacher">Teacher</option>
                          <option value="Health Worker">Health Worker</option>
                          <option value="Farmer">Farmer</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="subsystem_access">Subsystem Access</label>
                        <select class="form-control" id="subsystem_access" name="subsystem_access" required>
                          <option value="">Select Subsystem</option>
                          <option value="Admin">Admin</option>
                          <option value="Parish">Parish</option>
                          <option value="Education">Education</option>
                          <option value="Health">Health</option>
                          <option value="Agriculture">Agriculture</option>
                        </select>
                      </div>

                      <div class="card-action">
                        <button type="submit" name="submit" class="btn btn-success">Add User</button>
                        <button type="reset" class="btn btn-danger">Cancel</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <footer class="footer">
          <div class="container-fluid d-flex justify-content-between">
            <nav class="pull-left">
              <ul class="nav">
                <li class="nav-item">
                  <a class="nav-link" href="http://www.themekita.com">
                    Catholic Diocese of Kimbe
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#"> Help </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#"> Licenses </a>
                </li>
              </ul>
            </nav>
            <div class="copyright">
              2024, made with <i class="fa fa-heart heart text-danger"></i> by
              <a href="http://www.themekita.com">Kimberly</a>
            </div>
            <div>
              Distributed by
              <a target="_blank" href="https://themewagon.com/">The Catholic Diocese of Kimbe</a>.
            </div>
          </div>
        </footer>
      </div>
    </div>

    <!--   Core JS Files   -->
    <script src="../system_admin/assets/js/core/jquery-3.7.1.min.js"></script>
    <script src="../system_admin/assets/js/core/popper.min.js"></script>
    <script src="../system_admin/assets/js/core/bootstrap.min.js"></script>

    <!-- jQuery Scrollbar -->
    <script src="../system_admin/assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>

    <!-- Chart JS -->
    <script src="../system_admin/assets/js/plugin/chart.js/chart.min.js"></script>

    <!-- jQuery Sparkline -->
    <script src="../system_admin/assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

    <!-- Chart Circle -->
    <script src="../system_admin/assets/js/plugin/chart-circle/circles.min.js"></script>

    <!-- Datatables -->
    <script src="../system_admin/assets/js/plugin/datatables/datatables.min.js"></script>

    <!-- Bootstrap Notify -->
    <script src="../system_admin/assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

    <!-- jQuery Vector Maps -->
    <script src="../system_admin/assets/js/plugin/jsvectormap/jsvectormap.min.js"></script>
    <script src="../system_admin/assets/js/plugin/jsvectormap/world.js"></script>

    <!-- Google Maps Plugin -->
    <script src="../system_admin/assets/js/plugin/gmaps/gmaps.js"></script>

    <!-- Sweet Alert -->
    <script src="../system_admin/assets/js/plugin/sweetalert/sweetalert.min.js"></script>

    <!-- Kaiadmin JS -->
    <script src="../system_admin/assets/js/kaiadmin.min.js"></script>

    <!-- Kaiadmin DEMO methods, don't include it in your project! -->
    <script src="../system_admin/assets/js/setting-demo2.js"></script>
  </body>
</html>
