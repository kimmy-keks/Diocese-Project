<?php
include 'db_connection.php'; // your DB connection file

// Get search and filter parameters
$search = isset($_GET['search']) ? $_GET['search'] : '';
$user_type_filter = isset($_GET['user_type']) ? $_GET['user_type'] : '';
$subsystem_filter = isset($_GET['subsystem']) ? $_GET['subsystem'] : '';

// Handle Deletion
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: manage_users.php");
    exit;
}

// Handle Update
if (isset($_POST['update_user'])) {
    $id = $_POST['edit_id'];
    $first_name = $_POST['edit_first_name'];
    $last_name = $_POST['edit_last_name'];
    $username = $_POST['edit_username'];
    $email = $_POST['edit_email'];
    $user_type = $_POST['edit_user_type'];
    $subsystem_access = $_POST['edit_subsystem_access'];
    
    // Handle photo upload
    $id_photo = '';
    if (isset($_FILES['edit_id_photo']) && $_FILES['edit_id_photo']['error'] == 0) {
        $upload_dir = '../uploads/user_photos/';
        if (!file_exists($upload_dir)) {
            if (!mkdir($upload_dir, 0777, true)) {
                error_log("Failed to create upload directory: " . $upload_dir);
            }
        }
        
        $file_extension = strtolower(pathinfo($_FILES['edit_id_photo']['name'], PATHINFO_EXTENSION));
        $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif');
        
        if (in_array($file_extension, $allowed_extensions)) {
            $new_filename = 'user_' . $id . '_' . time() . '.' . $file_extension;
            $upload_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['edit_id_photo']['tmp_name'], $upload_path)) {
                $id_photo = 'uploads/user_photos/' . $new_filename;
                
                // Update database with new photo path
                $stmt = $conn->prepare("UPDATE users SET first_name=?, last_name=?, username=?, email=?, user_type=?, subsystem_access=?, id_photo=? WHERE id=?");
                if (!$stmt->execute([$first_name, $last_name, $username, $email, $user_type, $subsystem_access, $id_photo, $id])) {
                    error_log("Database update failed: " . $stmt->error);
                }
            } else {
                error_log("Failed to move uploaded file to: " . $upload_path);
            }
        } else {
            error_log("Invalid file type uploaded: " . $file_extension);
        }
    } else {
        // If no new photo uploaded, update other fields only
        $stmt = $conn->prepare("UPDATE users SET first_name=?, last_name=?, username=?, email=?, user_type=?, subsystem_access=? WHERE id=?");
        if (!$stmt->execute([$first_name, $last_name, $username, $email, $user_type, $subsystem_access, $id])) {
            error_log("Database update failed: " . $stmt->error);
        }
    }

    header("Location: manage_users.php");
    exit;
}

// Handle User Addition
if (isset($_POST['add_user'])) {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $user_type = $_POST['user_type'];
    $subsystem_access = $_POST['subsystem_access'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password
    
    // Handle photo upload
    $id_photo = '';
    if (isset($_FILES['id_photo']) && $_FILES['id_photo']['error'] == 0) {
        $upload_dir = '../uploads/user_photos/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES['id_photo']['name'], PATHINFO_EXTENSION));
        $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif');
        
        if (in_array($file_extension, $allowed_extensions)) {
            $new_filename = 'user_' . time() . '.' . $file_extension;
            $upload_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['id_photo']['tmp_name'], $upload_path)) {
                $id_photo = 'uploads/user_photos/' . $new_filename;
            }
        }
    }

    // Insert new user
    $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, username, email, password, user_type, subsystem_access, id_photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$first_name, $last_name, $username, $email, $password, $user_type, $subsystem_access, $id_photo]);

    header("Location: manage_users.php");
    exit;
}

// Fetch users with search and filters
$query = "SELECT * FROM users WHERE 1=1";
$params = array();
$types = "";

if (!empty($search)) {
    $search = "%$search%";
    $query .= " AND (CONCAT(first_name, ' ', last_name) LIKE ? OR CONCAT(last_name, ' ', first_name) LIKE ?)";
    $params[] = $search;
    $params[] = $search;
    $types .= "ss";
}

if (!empty($user_type_filter)) {
    $query .= " AND user_type = ?";
    $params[] = $user_type_filter;
    $types .= "s";
}

if (!empty($subsystem_filter)) {
    $query .= " AND subsystem_access = ?";
    $params[] = $subsystem_filter;
    $types .= "s";
}

$query .= " ORDER BY first_name, last_name";

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$users = [];
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Manage Users</title>
    <meta
      content="width=device-width, initial-scale=1.0, shrink-to-fit=no"
      name="viewport"
    />
    <link
      rel="icon"
      href="../parish/assets/img/kaiadmin/favicon.ico"
      type="image/x-icon"
    />

    <!-- Fonts and icons -->
    <script src="../system_admin/assets/js/plugin/webfont/webfont.min.js"></script>
    <script>
      WebFont.load({
        google: { families: ["Public Sans:300,400,500,600,700"] },
        custom: {
          families: [
            "Font Awesome 5 Solid",
            "Font Awesome 5 Regular",
            "Font Awesome 5 Brands",
            "simple-line-icons",
          ],
          urls: ["../system_admin/assets/css/fonts.min.css"],
        },
        active: function () {
          sessionStorage.fonts = true;
        },
      });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="../system_admin/assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../system_admin/assets/css/plugins.min.css" />
    <link rel="stylesheet" href="../system_admin/assets/css/kaiadmin.min.css" />

    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link rel="stylesheet" href="../system_admin/assets/css/demo.css" />
  </head>
  <body>
    <div class="wrapper">
      <!-- Sidebar -->
      <div class="sidebar" data-background-color="dark">
        <div class="sidebar-logo">
          <!-- Logo Header -->
          <div class="logo-header" data-background-color="dark">
            <a href="../parish/index.html" class="logo">
              <img
                src="../images/logo.png"
                alt="navbar brand"
                class="navbar-brand"
                height="30"
              />
            </a>
            <div class="nav-toggle">
              <button class="btn btn-toggle toggle-sidebar">
                <i class="gg-menu-right"></i>
              </button>
              <button class="btn btn-toggle sidenav-toggler">
                <i class="gg-menu-left"></i>
              </button>
            </div>
            <button class="topbar-toggler more">
              <i class="gg-more-vertical-alt"></i>
            </button>
          </div>
          <!-- End Logo Header -->
        </div>
        <div class="sidebar-wrapper scrollbar scrollbar-inner">
          <div class="sidebar-content">
            <ul class="nav nav-secondary">
              <li class="nav-item">
                <a href="../parish/index.html">
                  <i class="fas fa-home"></i>
                  <p>Admin Dashboard</p>
                </a>
              </li>
              <li class="nav-section">
                <span class="sidebar-mini-icon">
                  <i class="fa fa-ellipsis-h"></i>
                </span>
                <h4 class="text-section">Components</h4>
              </li>
              <li class="nav-item">
                <a data-bs-toggle="collapse" href="#forms">
                  <i class="fas fa-pen-square"></i>
                  <p>Forms</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse" id="forms">
                  <ul class="nav nav-collapse">
                    <li>
                      <a href="../system_admin/forms/deaneryinfo.php">
                        <span class="sub-item">Deanery</span>
                      </a>
                    </li>
                    <li>
                      <a href="../system_admin/forms/parishinfo.php">
                        <span class="sub-item">Parish</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
              <li class="nav-item">
                <a data-bs-toggle="collapse" href="#tables">
                  <i class="fas fa-table"></i>
                  <p>Records</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse" id="tables">
                  <ul class="nav nav-collapse">
                    <li>
                      <a href="../system_admin/tables/deaneryrecords.php">
                        <span class="sub-item">Deanery Records</span>
                      </a>
                    </li>
                    <li>
                      <a href="../system_admin/tables/parishrecords.php">
                        <span class="sub-item">Parish Records</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
              <li class="nav-item">
                <a data-bs-toggle="collapse" href="#charts">
                  <i class="far fa-chart-bar"></i>
                  <p>Charts</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse" id="charts">
                  <ul class="nav nav-collapse">
                    <li>
                      <a href="../system_admin/charts/parishcharts.php">
                        <span class="sub-item">Parish Charts</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
              <li class="nav-item active">
                <a data-bs-toggle="collapse" href="#users" class="collapsed" aria-expanded="false">
                  <i class="fas fa-users"></i>
                  <p>Users</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse show" id="users">
                  <ul class="nav nav-collapse">
                    <li>
                      <a href="add_users.php">
                        <span class="sub-item">Add User</span>
                      </a>
                    </li>
                    <li class="active">
                      <a href="manage_users.php">
                        <span class="sub-item">Manage Users</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <!-- End Sidebar -->

      <div class="main-panel">
        <div class="main-header">
          <div class="main-header-logo">
            <!-- Logo Header -->
            <div class="logo-header" data-background-color="dark">
              <a href="../parish/index.html" class="logo">
                <img
                  src="../images/logo.png"
                  alt="navbar brand"
                  class="navbar-brand"
                  height="20"
                />
              </a>
              <div class="nav-toggle">
                <button class="btn btn-toggle toggle-sidebar">
                  <i class="gg-menu-right"></i>
                </button>
                <button class="btn btn-toggle sidenav-toggler">
                  <i class="gg-menu-left"></i>
                </button>
              </div>
              <button class="topbar-toggler more">
                <i class="gg-more-vertical-alt"></i>
              </button>
            </div>
            <!-- End Logo Header -->
          </div>
          <!-- Navbar Header -->
          <nav
            class="navbar navbar-header navbar-header-transparent navbar-expand-lg border-bottom"
          >
            <div class="container-fluid">
              <nav
                class="navbar navbar-header-left navbar-expand-lg navbar-form nav-search p-0 d-none d-lg-flex"
              >
                <div class="input-group">
                  <div class="input-group-prepend">
                    <button type="submit" class="btn btn-search pe-1">
                      <i class="fa fa-search search-icon"></i>
                    </button>
                  </div>
                  <form action="manage_users.php" method="GET" class="d-flex">
                    <input
                      type="text"
                      name="search"
                      placeholder="Search users..."
                      class="form-control"
                      value="<?php echo htmlspecialchars($search); ?>"
                    />
                  </form>
                </div>
              </nav>

              <ul class="navbar-nav topbar-nav ms-md-auto align-items-center">
                <li
                  class="nav-item topbar-icon dropdown hidden-caret d-flex d-lg-none"
                >
                  <a
                    class="nav-link dropdown-toggle"
                    data-bs-toggle="dropdown"
                    href="#"
                    role="button"
                    aria-expanded="false"
                    aria-haspopup="true"
                  >
                    <i class="fa fa-search"></i>
                  </a>
                  <ul class="dropdown-menu dropdown-search animated fadeIn">
                    <form class="navbar-left navbar-form nav-search" action="manage_users.php" method="GET">
                      <div class="input-group">
                        <input
                          type="text"
                          name="search"
                          placeholder="Search users..."
                          class="form-control"
                          value="<?php echo htmlspecialchars($search); ?>"
                        />
                      </div>
                    </form>
                  </ul>
                </li>
              </ul>
            </div>
          </nav>
        </div>
        <div class="container">
          <div class="page-inner">
            <div class="page-header">
              <h3 class="fw-bold mb-3">User Management</h3>
              <ul class="breadcrumbs mb-3">
                <li class="nav-home">
                  <a href="#">
                    <i class="icon-home"></i>
                  </a>
                </li>
                <li class="separator">
                  <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                  <a href="#">Users</a>
                </li>
                <li class="separator">
                  <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                  <a href="#">Manage Users</a>
                </li>
              </ul>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                      <div class="card-title">User List</div>
                      <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUserModal">
                        <i class="fas fa-plus"></i> Add New User
                      </button>
                    </div>
                  </div>
                  <div class="card-body">
                    <!-- Add Filter Section -->
                    <div class="row mb-3">
                      <div class="col-md-4">
                        <form action="manage_users.php" method="GET" class="d-flex gap-2">
                          <select name="user_type" class="form-control" onchange="this.form.submit()">
                            <option value="">All User Types</option>
                            <option value="Admin" <?php echo $user_type_filter === 'Admin' ? 'selected' : ''; ?>>Admin</option>
                            <option value="Parish Priest" <?php echo $user_type_filter === 'Parish Priest' ? 'selected' : ''; ?>>Parish Priest</option>
                            <option value="Teacher" <?php echo $user_type_filter === 'Teacher' ? 'selected' : ''; ?>>Teacher</option>
                            <option value="Health Worker" <?php echo $user_type_filter === 'Health Worker' ? 'selected' : ''; ?>>Health Worker</option>
                            <option value="Farmer" <?php echo $user_type_filter === 'Farmer' ? 'selected' : ''; ?>>Farmer</option>
                          </select>
                          <select name="subsystem" class="form-control" onchange="this.form.submit()">
                            <option value="">All Subsystems</option>
                            <option value="system_admin" <?php echo $subsystem_filter === 'system_admin' ? 'selected' : ''; ?>>System Admin</option>
                            <option value="Parish" <?php echo $subsystem_filter === 'Parish' ? 'selected' : ''; ?>>Parish</option>
                            <option value="Education" <?php echo $subsystem_filter === 'Education' ? 'selected' : ''; ?>>Education</option>
                            <option value="Health" <?php echo $subsystem_filter === 'Health' ? 'selected' : ''; ?>>Health</option>
                            <option value="Agriculture" <?php echo $subsystem_filter === 'Agriculture' ? 'selected' : ''; ?>>Agriculture</option>
                          </select>
                          <?php if (!empty($search)): ?>
                            <input type="hidden" name="search" value="<?php echo htmlspecialchars($search); ?>">
                          <?php endif; ?>
                        </form>
                      </div>
                    </div>
                    <div class="table-responsive">
                      <table class="table table-bordered">
                        <thead>
                          <tr>
                            <th>ID</th>
                            <th>Photo</th>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Type</th>
                            <th>Subsystem</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php foreach ($users as $user): ?>
                          <tr>
                            <td><?= $user['id'] ?></td>
                            <td>
                              <?php if (!empty($user['id_photo'])): ?>
                                <img src="../<?= htmlspecialchars($user['id_photo']) ?>" alt="ID Photo" style="width: 50px; height: 50px; object-fit: cover;">
                              <?php else: ?>
                                <span class="text-muted">No photo</span>
                              <?php endif; ?>
                            </td>
                            <td><?= $user['first_name'] . ' ' . $user['last_name'] ?></td>
                            <td><?= $user['username'] ?></td>
                            <td><?= $user['email'] ?></td>
                            <td><?= $user['user_type'] ?></td>
                            <td><?= $user['subsystem_access'] ?></td>
                            <td>
                              <button class="btn btn-sm btn-primary" onclick='openEditModal(<?= json_encode($user) ?>)'>Edit</button>
                              <a href="?delete=<?= $user['id'] ?>" onclick="return confirm('Delete this user?')" class="btn btn-sm btn-danger">Delete</a>
                            </td>
                          </tr>
                          <?php endforeach; ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <footer class="footer">
          <div class="container-fluid d-flex justify-content-between">
            <nav class="pull-left">
              <ul class="nav">
                <li class="nav-item">
                  <a class="nav-link" href="http://www.themekita.com">
                    Catholic Diocese of Kimbe
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#"> Help </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#"> Licenses </a>
                </li>
              </ul>
            </nav>
            <div class="copyright">
              2024, made with <i class="fa fa-heart heart text-danger"></i> by
              <a href="http://www.themekita.com">Kimberly</a>
            </div>
            <div>
              Distributed by
              <a target="_blank" href="https://themewagon.com/">The Catholic Diocese of Kimbe</a>.
            </div>
          </div>
        </footer>
      </div>
    </div>

    <!-- Edit Modal -->
    <div class="modal fade" id="editUserModal" tabindex="-1">
      <div class="modal-dialog">
        <form method="POST" class="modal-content" enctype="multipart/form-data">
          <div class="modal-header">
            <h5 class="modal-title">Edit User</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" name="edit_id" id="edit_id">
            <div class="form-group">
              <label for="edit_first_name">First Name</label>
              <input type="text" name="edit_first_name" id="edit_first_name" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="edit_last_name">Last Name</label>
              <input type="text" name="edit_last_name" id="edit_last_name" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="edit_username">Username</label>
              <input type="text" name="edit_username" id="edit_username" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="edit_email">Email</label>
              <input type="email" name="edit_email" id="edit_email" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="edit_user_type">User Type</label>
              <select name="edit_user_type" id="edit_user_type" class="form-control" required>
                <option value="Parish Priest">Parish Priest</option>
                <option value="Teacher">Teacher</option>
                <option value="Health Worker">Health Worker</option>
                <option value="Farmer">Farmer</option>
                <option value="Admin">Admin </option>
              </select>
            </div>
            <div class="form-group">
              <label for="edit_subsystem_access">Subsystem Access</label>
              <select name="edit_subsystem_access" id="edit_subsystem_access" class="form-control" required>
                <option value="Parish">Parish</option>
                <option value="Education">Education</option>
                <option value="Health">Health</option>
                <option value="Agriculture">Agriculture</option>
                <option value="Admin">Admin System</option>
              </select>
            </div>
            <div class="form-group">
              <label for="edit_id_photo">ID Photo</label>
              <input type="file" name="edit_id_photo" id="edit_id_photo" class="form-control" accept="image/*">
              <small class="form-text text-muted">Upload a photo (JPG, JPEG, PNG, or GIF)</small>
              <div id="current_photo" class="mt-2" style="display: none;">
                <p>Current Photo:</p>
                <img id="current_photo_preview" src="" alt="Current Photo" style="max-width: 150px; max-height: 150px;">
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" name="update_user" class="btn btn-success">Save Changes</button>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Add User Modal -->
    <div class="modal fade" id="addUserModal" tabindex="-1">
      <div class="modal-dialog">
        <form method="POST" class="modal-content" enctype="multipart/form-data">
          <div class="modal-header">
            <h5 class="modal-title">Add New User</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label for="first_name">First Name</label>
              <input type="text" name="first_name" id="first_name" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="last_name">Last Name</label>
              <input type="text" name="last_name" id="last_name" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="username">Username</label>
              <input type="text" name="username" id="username" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="email">Email</label>
              <input type="email" name="email" id="email" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="password">Password</label>
              <input type="password" name="password" id="password" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="user_type">User Type</label>
              <select name="user_type" id="user_type" class="form-control" required>
                <option value="Parish Priest">Parish Priest</option>
                <option value="Teacher">Teacher</option>
                <option value="Health Worker">Health Worker</option>
                <option value="Farmer">Farmer</option>
              </select>
            </div>
            <div class="form-group">
              <label for="subsystem_access">Subsystem Access</label>
              <select name="subsystem_access" id="subsystem_access" class="form-control" required>
                <option value="Parish">Parish</option>
                <option value="Education">Education</option>
                <option value="Health">Health</option>
                <option value="Agriculture">Agriculture</option>
              </select>
            </div>
            <div class="form-group">
              <label for="id_photo">ID Photo</label>
              <input type="file" name="id_photo" id="id_photo" class="form-control" accept="image/*">
              <small class="form-text text-muted">Upload a photo (JPG, JPEG, PNG, or GIF)</small>
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" name="add_user" class="btn btn-success">Add User</button>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div>

    <!--   Core JS Files   -->
    <script src="../system_admin/assets/js/core/jquery-3.7.1.min.js"></script>
    <script src="../system_admin/assets/js/core/popper.min.js"></script>
    <script src="../system_admin/assets/js/core/bootstrap.min.js"></script>

    <!-- jQuery Scrollbar -->
    <script src="../systen_admin/assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>

    <!-- Chart JS -->
    <script src="../system_admin/assets/js/plugin/chart.js/chart.min.js"></script>

    <!-- jQuery Sparkline -->
    <script src="../system_admin/assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

    <!-- Chart Circle -->
    <script src="../system_admin/assets/js/plugin/chart-circle/circles.min.js"></script>

    <!-- Datatables -->
    <script src="../system_admin/assets/js/plugin/datatables/datatables.min.js"></script>

    <!-- Bootstrap Notify -->
    <script src="../system_admin/assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

    <!-- jQuery Vector Maps -->
    <script src="../system_admin/assets/js/plugin/jsvectormap/jsvectormap.min.js"></script>
    <script src="../system_admin/assets/js/plugin/jsvectormap/world.js"></script>

    <!-- Google Maps Plugin -->
    <script src="../system_admin/assets/js/plugin/gmaps/gmaps.js"></script>

    <!-- Sweet Alert -->
    <script src="../system_admin/assets/js/plugin/sweetalert/sweetalert.min.js"></script>

    <!-- Kaiadmin JS -->
    <script src="../system_admin/assets/js/kaiadmin.min.js"></script>

    <!-- Kaiadmin DEMO methods, don't include it in your project! -->
    <script src="../system_admin/assets/js/setting-demo2.js"></script>

    <script>
      function openEditModal(user) {
        document.getElementById('edit_id').value = user.id;
        document.getElementById('edit_first_name').value = user.first_name;
        document.getElementById('edit_last_name').value = user.last_name;
        document.getElementById('edit_username').value = user.username;
        document.getElementById('edit_email').value = user.email;
        document.getElementById('edit_user_type').value = user.user_type;
        document.getElementById('edit_subsystem_access').value = user.subsystem_access;
        
        // Handle current photo display
        const currentPhotoDiv = document.getElementById('current_photo');
        const currentPhotoPreview = document.getElementById('current_photo_preview');
        if (user.id_photo) {
          currentPhotoPreview.src = '../' + user.id_photo;
          currentPhotoDiv.style.display = 'block';
        } else {
          currentPhotoDiv.style.display = 'none';
        }

        new bootstrap.Modal(document.getElementById('editUserModal')).show();
      }

      // Add search functionality
      document.addEventListener('DOMContentLoaded', function() {
        const searchInputs = document.querySelectorAll('input[name="search"]');
        const searchForms = document.querySelectorAll('form[action="manage_users.php"]');

        searchInputs.forEach(input => {
          input.addEventListener('input', function() {
            if (this.value.trim() === '') {
              // If search is cleared, submit the form to show all users
              this.closest('form').submit();
            }
          });

          // Add event listener for form submission
          input.closest('form').addEventListener('submit', function(e) {
            if (input.value.trim() === '') {
              e.preventDefault();
              window.location.href = 'manage_users.php';
            }
          });
        });
      });
    </script>
  </body>
</html>
