<?php
// Include database connection
require_once 'db_connection.php';

// Initialize statistics array
$stats = array();

try {
    // Get user type statistics
    $query = "SELECT 
        user_type,
        COUNT(*) as count
    FROM users 
    GROUP BY user_type";
    $result = mysqli_query($conn, $query);
    
    // Initialize user type counts
    $stats['users'] = array(
        'total_users' => 0,
        'admins' => 0,
        'parish_priests' => 0,
        'teachers' => 0,
        'health_workers' => 0,
        'farmers' => 0
    );

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $stats['users']['total_users'] += $row['count'];
            switch ($row['user_type']) {
                case 'Admin':
                    $stats['users']['admins'] = $row['count'];
                    break;
                case 'Parish Priest':
                    $stats['users']['parish_priests'] = $row['count'];
                    break;
                case 'Teacher':
                    $stats['users']['teachers'] = $row['count'];
                    break;
                case 'Health Worker':
                    $stats['users']['health_workers'] = $row['count'];
                    break;
                case 'Farmer':
                    $stats['users']['farmers'] = $row['count'];
                    break;
            }
        }
    }

    // Get admin count from subsystem_access if not found in user_type
    if ($stats['users']['admins'] == 0) {
        $query = "SELECT COUNT(*) as admin_count FROM users WHERE subsystem_access = 'Admin'";
        $result = mysqli_query($conn, $query);
        if ($result) {
            $row = mysqli_fetch_assoc($result);
            $stats['users']['admins'] = $row['admin_count'];
        }
    }

    // Get parish statistics
    $query = "SELECT COUNT(*) as total_parishes FROM parishes";
    $result = mysqli_query($conn, $query);
    if ($result) {
        $stats['parishes'] = mysqli_fetch_assoc($result);
    } else {
        $stats['parishes'] = array('total_parishes' => 0);
    }

    // Get deanery statistics
    $query = "SELECT COUNT(*) as total_deaneries FROM deaneries";
    $result = mysqli_query($conn, $query);
    if ($result) {
        $stats['deaneries'] = mysqli_fetch_assoc($result);
    } else {
        $stats['deaneries'] = array('total_deaneries' => 0);
    }

    // Get CPC statistics
    $query = "SELECT COUNT(*) as total_cpcs FROM cpcs";
    $result = mysqli_query($conn, $query);
    if ($result) {
        $stats['cpcs'] = mysqli_fetch_assoc($result);
    } else {
        $stats['cpcs'] = array('total_cpcs' => 0);
    }

    // Get LKK statistics
    $query = "SELECT COUNT(*) as total_lkks FROM lkks";
    $result = mysqli_query($conn, $query);
    if ($result) {
        $stats['lkks'] = mysqli_fetch_assoc($result);
    } else {
        $stats['lkks'] = array('total_lkks' => 0);
    }

    // Get Parishioner statistics
    $query = "SELECT COUNT(*) as total_parishioners FROM parishioners";
    $result = mysqli_query($conn, $query);
    if ($result) {
        $stats['parishioners'] = mysqli_fetch_assoc($result);
    } else {
        $stats['parishioners'] = array('total_parishioners' => 0);
    }

    // Get Sacrament statistics
    $query = "SELECT COUNT(*) as total_sacraments FROM sacraments";
    $result = mysqli_query($conn, $query);
    if ($result) {
        $stats['sacraments'] = mysqli_fetch_assoc($result);
    } else {
        $stats['sacraments'] = array('total_sacraments' => 0);
    }

} catch (Exception $e) {
    // Handle any errors
    error_log("Error in statistics.php: " . $e->getMessage());
    // Initialize with default values if there's an error
    $stats = array(
        'users' => array(
            'total_users' => 0,
            'admins' => 0,
            'parish_priests' => 0,
            'teachers' => 0,
            'health_workers' => 0,
            'farmers' => 0
        ),
        'parishes' => array('total_parishes' => 0),
        'deaneries' => array('total_deaneries' => 0),
        'cpcs' => array('total_cpcs' => 0),
        'lkks' => array('total_lkks' => 0),
        'parishioners' => array('total_parishioners' => 0),
        'sacraments' => array('total_sacraments' => 0)
    );
}

// Return the statistics array
return $stats;
?> 