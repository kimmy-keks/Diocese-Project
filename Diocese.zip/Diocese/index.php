<?php
session_start();
include 'php/db_connection.php'; // Make sure this file sets $conn = new mysqli(...)

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Prepare and execute query
    $stmt = $conn->prepare("SELECT id, username, password, user_type, subsystem_access, email, first_name, last_name, id_photo FROM users WHERE username = ? OR email = ?");
    $stmt->bind_param("ss", $username, $username); // allow login by username or email
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Verify hashed password
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['user_type'] = $user['user_type'];
            $_SESSION['subsystem_access'] = $user['subsystem_access'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['first_name'] = $user['first_name'];
            $_SESSION['last_name'] = $user['last_name'];
            $_SESSION['user_name'] = trim($user['first_name'] . ' ' . $user['last_name']);
            $_SESSION['user_photo'] = !empty($user['id_photo']) ? $user['id_photo'] : 'assets/img/default-avatar.jpg';
            $_SESSION['login_message'] = 'Welcome, ' . htmlspecialchars($user['username']) . ' (' . htmlspecialchars($user['user_type']) . ')!';
            // Redirect based on subsystem_access
            switch (strtolower($user['subsystem_access'])) {
                case 'admin':
                    header("Location: system_admin/index.php");
                    break;
                case 'education':
                    header("Location: education/dashboard.php");
                    break;
                case 'health':
                    header("Location: health/dashboard.php");
                    break;
                case 'finance':
                    header("Location: finance/dashboard.php");
                    break;
                case 'parish':
                    header("Location: parish/index.php");
                    break;
                default:
                    header("Location: dashboard.php"); // fallback
            }
            exit();
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "User not found.";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>Login - Diocese Management System</title>
  <meta content="width=device-width, initial-scale=1.0, shrink-to-fit=no" name="viewport" />
  <link rel="icon" href="parish/assets/img/kaiadmin/favicon.ico" type="image/x-icon" />

  <!-- Fonts and icons -->
  <script src="parish/assets/js/plugin/webfont/webfont.min.js"></script>
  <script>
    WebFont.load({
      google: { families: ["Public Sans:300,400,500,600,700"] },
      custom: {
        families: [
          "Font Awesome 5 Solid",
          "Font Awesome 5 Regular",
          "Font Awesome 5 Brands",
          "simple-line-icons",
        ],
        urls: ["parish/assets/css/fonts.min.css"],
      },
      active: function () {
        sessionStorage.fonts = true;
      },
    });
  </script>

  <!-- CSS Files -->
  <link rel="stylesheet" href="parish/assets/css/bootstrap.min.css" />
  <link rel="stylesheet" href="parish/assets/css/plugins.min.css" />
  <link rel="stylesheet" href="parish/assets/css/kaiadmin.min.css" />
  <link rel="stylesheet" href="parish/assets/css/demo.css" />
  <style>
    body {
      background: #f7f7f7;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .login-card {
      max-width: 400px;
      margin: 60px auto;
      box-shadow: 0 0 20px rgba(0,0,0,0.08);
      border-radius: 10px;
    }
    .login-logo {
      display: flex;
      justify-content: center;
      margin-bottom: 20px;
    }
    .login-logo img {
      height: 60px;
    }
    .footer-text {
      font-size: 0.85rem;
      margin-top: 1rem;
      color: #888;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="row justify-content-center align-items-center min-vh-100">
      <div class="col-12 col-sm-10 col-md-8 col-lg-6 col-xl-5">
        <div class="card login-card">
          <div class="card-header text-center bg-white border-0">
            <div class="login-logo mb-3 w-100 d-flex justify-content-center">
              <img src="images/logo.png" alt="Logo" class="img-fluid" style="max-height: 70px; width: auto;" />
            </div>
            <h3 class="fw-bold mb-0">Diocese Login</h3>
          </div>
          <div class="card-body">
            <?php if ($error): ?>
              <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            <form method="POST">
              <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" class="form-control" required autofocus>
              </div>
              <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" class="form-control" required>
              </div>
              <button type="submit" class="btn btn-primary w-100">Login</button>
            </form>
            <div class="footer-text">© 2025 Catholic Diocese of Kimbe</div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="parish/assets/js/core/jquery-3.7.1.min.js"></script>
  <script src="parish/assets/js/core/popper.min.js"></script>
  <script src="parish/assets/js/core/bootstrap.min.js"></script>
  <script src="parish/assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
  <script src="parish/assets/js/kaiadmin.min.js"></script>
  <script src="parish/assets/js/setting-demo2.js"></script>
</body>
</html>
