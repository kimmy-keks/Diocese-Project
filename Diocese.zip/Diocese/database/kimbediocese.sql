-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 11, 2025 at 03:08 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kimbediocese`
--

-- --------------------------------------------------------

--
-- Table structure for table `cpcs`
--

CREATE TABLE `cpcs` (
  `id` int(11) NOT NULL,
  `parish_name` text NOT NULL,
  `cpc_name` text NOT NULL,
  `cpc_chairman` text NOT NULL,
  `cpc_chairman_contact` text DEFAULT NULL,
  `cpc_vice_chairman` text DEFAULT NULL,
  `cpc_secretary` text DEFAULT NULL,
  `cpc_treasurer` text DEFAULT NULL,
  `committee_heads` text DEFAULT NULL,
  `meeting_schedules` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cpcs`
--

INSERT INTO `cpcs` (`id`, `parish_name`, `cpc_name`, `cpc_chairman`, `cpc_chairman_contact`, `cpc_vice_chairman`, `cpc_secretary`, `cpc_treasurer`, `committee_heads`, `meeting_schedules`, `created_at`) VALUES
(1, 'Kimbe', 'St Lucy', 'Beno', '2948204', 'Kalina', 'Concepta', 'Ruth', 'John, Peter, James, Jacinta', '5/07/2025, 2/2/2343', '2025-07-08 20:42:16');

-- --------------------------------------------------------

--
-- Table structure for table `deaneries`
--

CREATE TABLE `deaneries` (
  `id` int(11) NOT NULL,
  `deanery_name` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `establishment_date` date NOT NULL,
  `dean` varchar(255) NOT NULL,
  `council_members` text DEFAULT NULL,
  `contact_phone` varchar(20) DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `deaneries`
--

INSERT INTO `deaneries` (`id`, `deanery_name`, `location`, `establishment_date`, `dean`, `council_members`, `contact_phone`, `contact_email`, `created_at`) VALUES
(1, 'Hoskins', 'Hoskins', '2025-05-23', 'Fr. Chris', 'Peter, John, Mark', '8329424', 'frchris@gmail.com', '2025-05-25 13:21:05'),
(2, 'Kandrian', 'Northcoast', '2025-05-21', 'Anna Mark', 'Peter, John, Mark', '8329424', 'frjoe@gmail.com', '2025-05-25 13:59:18');

-- --------------------------------------------------------

--
-- Table structure for table `lkks`
--

CREATE TABLE `lkks` (
  `id` int(11) NOT NULL,
  `cpc_id` int(11) NOT NULL,
  `lkk_name` text NOT NULL,
  `chairperson` text NOT NULL,
  `secretary` text DEFAULT NULL,
  `contact` text DEFAULT NULL,
  `number_of_members` int(11) DEFAULT NULL,
  `village` text DEFAULT NULL,
  `meeting_schedule` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lkks`
--

INSERT INTO `lkks` (`id`, `cpc_id`, `lkk_name`, `chairperson`, `secretary`, `contact`, `number_of_members`, `village`, `meeting_schedule`, `created_at`) VALUES
(1, 1, 'Sacred Heart ', 'Louisa', 'Anna ', '385482', 1312, 'Morokea', '6/7/2003, 23/09/1294', '2025-07-08 20:54:54'),
(2, 1, 'Peter Paul', 'Lucy', 'Kim', '4885837', 65, 'Kandrian', '7/3/2304, 12/07/2025', '2025-07-08 22:36:46');

-- --------------------------------------------------------

--
-- Table structure for table `parishes`
--

CREATE TABLE `parishes` (
  `id` int(11) NOT NULL,
  `deanery_id` int(11) NOT NULL,
  `parish_name` varchar(255) NOT NULL,
  `priest_id` int(11) DEFAULT NULL,
  `assistant_priest_id` int(11) DEFAULT NULL,
  `date_established` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parishes`
--

INSERT INTO `parishes` (`id`, `deanery_id`, `parish_name`, `priest_id`, `assistant_priest_id`, `date_established`, `created_at`) VALUES
(1, 2, 'Walango', 5, 1, '2025-05-22', '2025-05-25 14:04:34'),
(2, 1, 'Kimbe', 1, 1, '2025-05-14', '2025-05-25 14:26:39'),
(3, 1, 'Turuk', 5, 8, '2025-05-22', '2025-05-26 11:44:26');

-- --------------------------------------------------------

--
-- Table structure for table `parishioners`
--

CREATE TABLE `parishioners` (
  `id` int(11) NOT NULL,
  `lkk_id` int(11) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `contact` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parishioners`
--

INSERT INTO `parishioners` (`id`, `lkk_id`, `first_name`, `last_name`, `date_of_birth`, `gender`, `contact`, `address`, `created_at`) VALUES
(7, 2, 'Cathlyne', 'Kipa', '2025-07-07', 'Female', '2847327', 'Taurama Lot 12', '2025-07-08 22:37:16');

-- --------------------------------------------------------

--
-- Table structure for table `sacraments`
--

CREATE TABLE `sacraments` (
  `id` int(11) NOT NULL,
  `parishioner_id` int(11) NOT NULL,
  `sacrament_type` varchar(50) NOT NULL,
  `date_received` date DEFAULT NULL,
  `place_received` varchar(100) DEFAULT NULL,
  `officiating_priest` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sacraments`
--

INSERT INTO `sacraments` (`id`, `parishioner_id`, `sacrament_type`, `date_received`, `place_received`, `officiating_priest`, `notes`) VALUES
(2, 7, 'Confirmation', '2025-07-28', 'Bali', 'Fr Chris', 'Second batch');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `id_photo` longblob DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(50) NOT NULL,
  `subsystem_access` enum('Admin','Parish','Education','Health','Agriculture') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `id_photo`, `username`, `email`, `password`, `user_type`, `subsystem_access`, `created_at`) VALUES
(1, 'Anna', 'Mark', 0x75706c6f6164732f757365725f70686f746f732f757365725f315f313734383234393636352e6a706567, 'amark', 'amark@gmail.com', '$2y$10$zu.KjE9fGWSDJUa7D.ZJnewEDBVqcO/RIWwu8cpDBe1rjhdV91CkC', 'Parish Priest', 'Parish', '2025-05-25 09:55:15'),
(4, 'Kimberly', 'Kipa', 0x75706c6f6164732f757365725f70686f746f732f757365725f345f313734383235303138332e6a7067, 'kkipa', 'kkipa@gmail.com', '$2y$10$/yiuwpdaq44EBCDQc1d5ZO/ODsKcbtL7GXOY7c/bIw0oDnXwxacSu', 'Teacher', 'Education', '2025-05-25 10:01:12'),
(5, 'Chris', 'Amun', 0x75706c6f6164732f757365725f70686f746f732f757365725f355f313734383235323537302e6a706567, 'fr_chrisamun', 'chrisamun@gmail.com', '$2y$10$sb2na1k0eIfoQORiy2Eub.x2.6ZlH.ELGqgnYiQ/aln60lgz9I8km', 'Parish Priest', 'Parish', '2025-05-25 14:01:55'),
(6, 'Cathlyne', 'Kipa', 0x75706c6f6164732f757365725f70686f746f732f757365725f313734383235303036332e6a706567, 'ckipa', 'ckipa@gmail.com', '$2y$10$8.0BT8mjBC7DUiwEYBc6TuaiOsrS5K4WCSvG/n4xXEVy9OteIeVOK', 'Teacher', 'Education', '2025-05-26 09:01:03'),
(7, 'Gabriella', 'Palaulo', 0x75706c6f6164732f757365725f70686f746f732f757365725f313734383235373633352e6a7067, 'gpalaulo', 'gpalaulo@gmail.com', '$2y$10$HQCC5pWFKurxQUoCulCPs.xx9d9I2RSFGLofrry1b/1we3N3VgoZy', 'Health Worker', 'Health', '2025-05-26 11:07:15'),
(8, 'Joshua', 'Kanawa', 0x75706c6f6164732f757365725f70686f746f732f757365725f313734383235393538302e6a706567, 'jokanawa', 'jokanawa@gmail.com', '$2y$10$4jrXViR/VDAnUoORXQYGCOqwdczbTB9yHvdzgzOqUzQyji9o7.a2y', 'Parish Priest', 'Parish', '2025-05-26 11:39:40'),
(13, 'Lulu', 'Lemon', 0x75706c6f6164732f757365725f70686f746f732f757365725f313735323138383139362e6a706567, 'llemon', 'llemon@gmail.com', '$2y$10$xCNZzTdqgCjj8gx.jSUtBerVE4cLk.jBtf1miQ0PMnRq.KSQbswpK', 'Admin', 'Admin', '2025-07-10 22:56:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cpcs`
--
ALTER TABLE `cpcs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deaneries`
--
ALTER TABLE `deaneries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lkks`
--
ALTER TABLE `lkks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cpc_id` (`cpc_id`);

--
-- Indexes for table `parishes`
--
ALTER TABLE `parishes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deanery_id` (`deanery_id`),
  ADD KEY `priest_id` (`priest_id`),
  ADD KEY `assistant_priest_id` (`assistant_priest_id`);

--
-- Indexes for table `parishioners`
--
ALTER TABLE `parishioners`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lkk_id` (`lkk_id`);

--
-- Indexes for table `sacraments`
--
ALTER TABLE `sacraments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parishioner_id` (`parishioner_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cpcs`
--
ALTER TABLE `cpcs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `deaneries`
--
ALTER TABLE `deaneries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lkks`
--
ALTER TABLE `lkks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `parishes`
--
ALTER TABLE `parishes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `parishioners`
--
ALTER TABLE `parishioners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `sacraments`
--
ALTER TABLE `sacraments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `lkks`
--
ALTER TABLE `lkks`
  ADD CONSTRAINT `lkks_ibfk_1` FOREIGN KEY (`cpc_id`) REFERENCES `cpcs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `parishes`
--
ALTER TABLE `parishes`
  ADD CONSTRAINT `parishes_ibfk_1` FOREIGN KEY (`deanery_id`) REFERENCES `deaneries` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `parishes_ibfk_2` FOREIGN KEY (`priest_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `parishes_ibfk_3` FOREIGN KEY (`assistant_priest_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `parishioners`
--
ALTER TABLE `parishioners`
  ADD CONSTRAINT `parishioners_ibfk_1` FOREIGN KEY (`lkk_id`) REFERENCES `lkks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sacraments`
--
ALTER TABLE `sacraments`
  ADD CONSTRAINT `sacraments_ibfk_1` FOREIGN KEY (`parishioner_id`) REFERENCES `parishioners` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
