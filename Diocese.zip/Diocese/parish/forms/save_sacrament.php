<?php
include '../../php/db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $parishioner_id = $_POST['parishioner_id'] ?? null;
    $sacrament_type = $_POST['sacrament_type'] ?? null;
    $date_received = $_POST['date_received'] ?? null;
    $place_received = $_POST['place_received'] ?? null;
    $officiating_priest = $_POST['officiating_priest'] ?? null;
    $notes = $_POST['notes'] ?? null;

    // Basic validation
    if ($parishioner_id && $sacrament_type) {
        $stmt = $conn->prepare("INSERT INTO sacraments (parishioner_id, sacrament_type, date_received, place_received, officiating_priest, notes) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param(
            'isssss',
            $parishioner_id,
            $sacrament_type,
            $date_received,
            $place_received,
            $officiating_priest,
            $notes
        );
        if ($stmt->execute()) {
            header('Location: sacramentsinfo.php?success=1');
            exit();
        } else {
            header('Location: sacramentsinfo.php?error=1');
            exit();
        }
    } else {
        header('Location: sacramentsinfo.php?error=1');
        exit();
    }
} else {
    header('Location: sacramentsinfo.php');
    exit();
} 