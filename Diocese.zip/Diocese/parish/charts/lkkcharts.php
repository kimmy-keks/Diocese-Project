<?php
// db_connection.php should define $conn as your mysqli connection
include '../../php/db_connection.php';

// Get filter parameters
$selected_year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
$selected_month = isset($_GET['month']) ? (int)$_GET['month'] : 0; // 0 means all months

// Get available years for dropdown
$years_sql = "SELECT DISTINCT YEAR(created_at) as year FROM lkks ORDER BY year DESC";
$years_result = $conn->query($years_sql);
$available_years = [];
while ($row = $years_result->fetch_assoc()) {
    $available_years[] = $row['year'];
}

// Build query based on filters
if ($selected_month > 0) {
    // Filter by specific month and year
    $sql = "SELECT DAY(created_at) as day, COUNT(*) as count
            FROM lkks
            WHERE YEAR(created_at) = ? AND MONTH(created_at) = ?
            GROUP BY DAY(created_at)
            ORDER BY day";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $selected_year, $selected_month);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Initialize array with 0 for each day of the month
    $days_in_month = date('t', mktime(0, 0, 0, $selected_month, 1, $selected_year));
    $chart_data = array_fill(1, $days_in_month, 0);
    $chart_labels = [];
    for ($i = 1; $i <= $days_in_month; $i++) {
        $chart_labels[] = $i;
    }
    
    while ($row = $result->fetch_assoc()) {
        $chart_data[(int)$row['day']] = (int)$row['count'];
    }
    $chart_data = array_values($chart_data);
} else {
    // Filter by year only (monthly data)
    $sql = "SELECT MONTH(created_at) as month, COUNT(*) as count
            FROM lkks
            WHERE YEAR(created_at) = ?
            GROUP BY MONTH(created_at)
            ORDER BY month";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $selected_year);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Initialize array with 0 for each month
    $chart_data = array_fill(1, 12, 0);
    $chart_labels = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    
    while ($row = $result->fetch_assoc()) {
        $chart_data[(int)$row['month']] = (int)$row['count'];
    }
    $chart_data = array_values($chart_data);
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php session_start(); ?>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>LKK Charts</title>
    <meta content="width=device-width, initial-scale=1.0, shrink-to-fit=no" name="viewport" />
    <link rel="icon" href="../assets/img/kaiadmin/favicon.ico" type="image/x-icon" />
    <!-- Fonts and icons -->
    <script src="../assets/js/plugin/webfont/webfont.min.js"></script>
    <script>
      WebFont.load({
        google: { families: ["Public Sans:300,400,500,600,700"] },
        custom: {
          families: [
            "Font Awesome 5 Solid",
            "Font Awesome 5 Regular",
            "Font Awesome 5 Brands",
            "simple-line-icons",
          ],
          urls: ["../assets/css/fonts.min.css"],
        },
        active: function () {
          sessionStorage.fonts = true;
        },
      });
    </script>
    <!-- CSS Files -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../assets/css/plugins.min.css" />
    <link rel="stylesheet" href="../assets/css/kaiadmin.min.css" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link rel="stylesheet" href="../assets/css/demo.css" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <style>
      .chart-container {
        display: flex;
        justify-content: center;
        align-items: flex-start;
        gap: 30px;
        margin: 20px auto 0 auto;
        max-width: 1200px;
        flex-wrap: wrap;
      }
      .chart-box {
        max-width: 500px;
        min-width: 300px;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.04);
        padding: 20px 10px 10px 10px;
        display: flex;
        flex-direction: column;
        align-items: center;
        margin: 0;
        flex: 1;
      }
      canvas {
        width: 500px !important;
        height: 300px !important;
        max-width: 100%;
        max-height: 100%;
        display: block;
        margin: 0 auto 10px auto;
      }
      .btn-success {
        background-color: #28a745;
        border-color: #28a745;
        color: white;
      }
      .btn-success:hover {
        background-color: #218838;
        border-color: #1e7e34;
        color: white;
      }
      .btn-success:disabled {
        background-color: #6c757d;
        border-color: #6c757d;
        opacity: 0.65;
      }
    </style>
  </head>
  <body>
    <div class="wrapper">
      <!-- Sidebar -->
      <div class="sidebar" data-background-color="dark">
        <div class="sidebar-logo">
          <!-- Logo Header -->
          <div class="logo-header" data-background-color="dark">
            <a href="../index.php" class="logo">
              <img src="../assets/img/logo.png" alt="navbar brand" class="navbar-brand" height="30" />
            </a>
            <div class="nav-toggle">
              <button class="btn btn-toggle toggle-sidebar">
                <i class="gg-menu-right"></i>
              </button>
              <button class="btn btn-toggle sidenav-toggler">
                <i class="gg-menu-left"></i>
              </button>
            </div>
            <button class="topbar-toggler more">
              <i class="gg-more-vertical-alt"></i>
            </button>
          </div>
          <!-- End Logo Header -->
        </div>
        <div class="sidebar-wrapper scrollbar scrollbar-inner">
          <div class="sidebar-content">
            <ul class="nav nav-secondary">
              <li class="nav-item">
                <a href="../index.php">
                  <i class="fas fa-home"></i>
                  <p>Parish Dashboard</p>
                </a>
              </li>
              <li class="nav-section">
                <span class="sidebar-mini-icon">
                  <i class="fa fa-ellipsis-h"></i>
                </span>
                <h4 class="text-section">Components</h4>
              </li>
              <li class="nav-item">
                <a data-bs-toggle="collapse" href="#forms">
                  <i class="fas fa-pen-square"></i>
                  <p>Forms</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse" id="forms">
                  <ul class="nav nav-collapse">
                    <li>
                      <a href="../forms/cpcinfo.php">
                        <span class="sub-item">CPC</span>
                      </a>
                    </li>
                    <li>
                      <a href="../forms/lkkinfo.php">
                        <span class="sub-item">LKK</span>
                      </a>
                    </li>
                    <li>
                      <a href="../forms/parishinfo.php">
                        <span class="sub-item">Parishioner</span>
                      </a>
                    </li>
                    <li>
                      <a href="../forms/parishinfo.php">
                        <span class="sub-item">Sacraments</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
              <li class="nav-item">
                <a data-bs-toggle="collapse" href="#tables">
                  <i class="fas fa-table"></i>
                  <p>Records</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse" id="tables">
                  <ul class="nav nav-collapse">
                    <li>
                      <a href="../tables/cpcrecords.php">
                        <span class="sub-item">CPC Records</span>
                      </a>
                    </li>
                    <li>
                      <a href="../tables/lkkrecords.php">
                        <span class="sub-item">LKK Records</span>
                      </a>
                    </li>
                    <li>
                      <a href="../tables/parishionerrecords.php">
                        <span class="sub-item">Parishioner Records</span>
                      </a>
                    </li>
                    <li>
                      <a href="../tables/parishionerrecords.php">
                        <span class="sub-item">Sacrament Records</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
              <li class="nav-item active submenu">
                <a data-bs-toggle="collapse" href="#charts">
                  <i class="far fa-chart-bar"></i>
                  <p>Charts</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse show" id="charts">
                  <ul class="nav nav-collapse">
                    <li>
                      <a href="parishcharts.php">
                        <span class="sub-item">Parish Charts</span>
                      </a>
                    </li>
                    <li>
                      <a href="cpccharts.php">
                        <span class="sub-item">CPC Charts</span>
                      </a>
                    </li>
                    <li>
                      <a href="lkkcharts.php" class="active">
                        <span class="sub-item">LKK Charts</span>
                      </a>
                    </li>
                    <li>
                      <a href="parishionercharts.php">
                        <span class="sub-item">Parishioner Charts</span>
                      </a>
                    </li>
                    <li>
                      <a href="sacramentcharts.php">
                        <span class="sub-item">Sacrament Charts</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <!-- End Sidebar -->
      <div class="main-panel">
        <div class="main-header">
          <div class="main-header-logo">
            <!-- Logo Header -->
            <div class="logo-header" data-background-color="dark">
              <a href="../index.php" class="logo">
                <img src="../assets/img/kaiadmin/logo_light.svg" alt="navbar brand" class="navbar-brand" height="20" />
              </a>
              <div class="nav-toggle">
                <button class="btn btn-toggle toggle-sidebar">
                  <i class="gg-menu-right"></i>
                </button>
                <button class="btn btn-toggle sidenav-toggler">
                  <i class="gg-menu-left"></i>
                </button>
              </div>
              <button class="topbar-toggler more">
                <i class="gg-more-vertical-alt"></i>
              </button>
            </div>
            <!-- End Logo Header -->
          </div>
          <!-- Navbar Header -->
          <nav class="navbar navbar-header navbar-header-transparent navbar-expand-lg border-bottom">
            <div class="container-fluid">
              <nav class="navbar navbar-header-left navbar-expand-lg navbar-form nav-search p-0 d-none d-lg-flex">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <button type="submit" class="btn btn-search pe-1">
                      <i class="fa fa-search search-icon"></i>
                    </button>
                  </div>
                  <input type="text" placeholder="Search ..." class="form-control" />
                </div>
              </nav>
              <ul class="navbar-nav topbar-nav ms-md-auto align-items-center">
                <!-- (User dropdown, notifications, etc. can be added here as needed) -->
              </ul>
            </div>
          </nav>
          <!-- End Navbar -->
        </div>
        <div class="container">
          <!-- Filter Controls -->
          <div class="filter-container" style="margin: 20px 0; text-align: center;">
            <form method="GET" action="" style="display: inline-flex; gap: 15px; align-items: center; flex-wrap: wrap; justify-content: center;">
              <div class="form-group" style="margin: 0;">
                <label for="year" style="margin-right: 5px; font-weight: 500;">Year:</label>
                <select name="year" id="year" class="form-control" style="width: auto; display: inline-block;">
                  <?php foreach ($available_years as $year): ?>
                    <option value="<?php echo $year; ?>" <?php echo ($year == $selected_year) ? 'selected' : ''; ?>>
                      <?php echo $year; ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="form-group" style="margin: 0;">
                <label for="month" style="margin-right: 5px; font-weight: 500;">Month:</label>
                <select name="month" id="month" class="form-control" style="width: auto; display: inline-block;">
                  <option value="0" <?php echo ($selected_month == 0) ? 'selected' : ''; ?>>All Months</option>
                  <option value="1" <?php echo ($selected_month == 1) ? 'selected' : ''; ?>>January</option>
                  <option value="2" <?php echo ($selected_month == 2) ? 'selected' : ''; ?>>February</option>
                  <option value="3" <?php echo ($selected_month == 3) ? 'selected' : ''; ?>>March</option>
                  <option value="4" <?php echo ($selected_month == 4) ? 'selected' : ''; ?>>April</option>
                  <option value="5" <?php echo ($selected_month == 5) ? 'selected' : ''; ?>>May</option>
                  <option value="6" <?php echo ($selected_month == 6) ? 'selected' : ''; ?>>June</option>
                  <option value="7" <?php echo ($selected_month == 7) ? 'selected' : ''; ?>>July</option>
                  <option value="8" <?php echo ($selected_month == 8) ? 'selected' : ''; ?>>August</option>
                  <option value="9" <?php echo ($selected_month == 9) ? 'selected' : ''; ?>>September</option>
                  <option value="10" <?php echo ($selected_month == 10) ? 'selected' : ''; ?>>October</option>
                  <option value="11" <?php echo ($selected_month == 11) ? 'selected' : ''; ?>>November</option>
                  <option value="12" <?php echo ($selected_month == 12) ? 'selected' : ''; ?>>December</option>
                </select>
              </div>
              <button type="submit" class="btn btn-primary" style="margin-left: 10px;">Apply Filter</button>
              <button type="button" id="printBtn" class="btn btn-success" style="margin-left: 10px;">
                <i class="fas fa-print"></i> Print to PDF
              </button>
            </form>
          </div>
          
          <div class="chart-container">
            <div class="chart-box">
              <h2 style="font-size:1.3rem;">
                LKK Records 
                <?php if ($selected_month > 0): ?>
                  (<?php echo date('F Y', mktime(0, 0, 0, $selected_month, 1, $selected_year)); ?>) - Line
                <?php else: ?>
                  (<?php echo $selected_year; ?>) - Line
                <?php endif; ?>
              </h2>
              <canvas id="lineChart"></canvas>
            </div>
            <div class="chart-box">
              <h2 style="font-size:1.3rem;">
                LKK Records 
                <?php if ($selected_month > 0): ?>
                  (<?php echo date('F Y', mktime(0, 0, 0, $selected_month, 1, $selected_year)); ?>) - Bar
                <?php else: ?>
                  (<?php echo $selected_year; ?>) - Bar
                <?php endif; ?>
              </h2>
              <canvas id="barChart"></canvas>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
      // PHP to JS: pass the chart data and labels
      const chartData = <?php echo json_encode($chart_data); ?>;
      const chartLabels = <?php echo json_encode($chart_labels); ?>;
      const selectedMonth = <?php echo $selected_month; ?>;
      const selectedYear = <?php echo $selected_year; ?>;
      
      // Determine label based on filter
      let dataLabel = 'Records per Month';
      if (selectedMonth > 0) {
          dataLabel = 'Records per Day';
      }
      
      // Line Chart
      new Chart(document.getElementById('lineChart').getContext('2d'), {
          type: 'line',
          data: {
              labels: chartLabels,
              datasets: [{
                  label: dataLabel,
                  data: chartData,
                  borderColor: '#1d7af3',
                  backgroundColor: 'rgba(29,122,243,0.1)',
                  fill: true,
                  tension: 0.3
              }]
          },
          options: {
              responsive: true,
              plugins: { 
                  legend: { display: true, position: 'top' },
                  tooltip: {
                      callbacks: {
                          title: function(context) {
                              if (selectedMonth > 0) {
                                  return 'Day ' + context[0].label;
                              } else {
                                  return context[0].label;
                              }
                          }
                      }
                  }
              },
              scales: {
                  x: {
                      title: {
                          display: true,
                          text: selectedMonth > 0 ? 'Day of Month' : 'Month'
                      }
                  },
                  y: {
                      title: {
                          display: true,
                          text: 'Number of Records'
                      }
                  }
              }
          }
      });
      
      // Bar Chart
      new Chart(document.getElementById('barChart').getContext('2d'), {
          type: 'bar',
          data: {
              labels: chartLabels,
              datasets: [{
                  label: dataLabel,
                  data: chartData,
                  backgroundColor: '#59d05d'
              }]
          },
          options: {
              responsive: true,
              plugins: { 
                  legend: { display: true, position: 'top' },
                  tooltip: {
                      callbacks: {
                          title: function(context) {
                              if (selectedMonth > 0) {
                                  return 'Day ' + context[0].label;
                              } else {
                                  return context[0].label;
                              }
                          }
                      }
                  }
              },
              scales: {
                  x: {
                      title: {
                          display: true,
                          text: selectedMonth > 0 ? 'Day of Month' : 'Month'
                      }
                  },
                  y: {
                      title: {
                          display: true,
                          text: 'Number of Records'
                      }
                  }
              }
          }
      });
      
      // PDF Generation Function
      document.addEventListener('DOMContentLoaded', function() {
          const printBtn = document.getElementById('printBtn');
          if (printBtn) {
              printBtn.addEventListener('click', function() {
                  generatePDF();
              });
          }
      });
      
      function generatePDF() {
          // Check if jsPDF is loaded
          if (typeof window.jspdf === 'undefined') {
              alert('PDF library not loaded. Please refresh the page and try again.');
              return;
          }
          
          const { jsPDF } = window.jspdf;
          const pdf = new jsPDF('p', 'mm', 'a4');
          
          // Show loading message
          const printBtn = document.getElementById('printBtn');
          const originalText = printBtn.innerHTML;
          printBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating PDF...';
          printBtn.disabled = true;
          
          // PDF settings
          const pageWidth = pdf.internal.pageSize.getWidth();
          const pageHeight = pdf.internal.pageSize.getHeight();
          const margin = 20;
          const contentWidth = pageWidth - (2 * margin);
          
          // Header
          pdf.setFontSize(20);
          pdf.setFont('helvetica', 'bold');
          pdf.text('LKK Records Report', pageWidth / 2, 30, { align: 'center' });
          
          // Filter information
          pdf.setFontSize(12);
          pdf.setFont('helvetica', 'normal');
          let filterText = `Year: ${selectedYear}`;
          if (selectedMonth > 0) {
              const monthNames = ['', 'January', 'February', 'March', 'April', 'May', 'June', 
                                 'July', 'August', 'September', 'October', 'November', 'December'];
              filterText += ` | Month: ${monthNames[selectedMonth]}`;
          }
          pdf.text(filterText, pageWidth / 2, 45, { align: 'center' });
          
          // Date generated
          const currentDate = new Date().toLocaleDateString();
          pdf.text(`Generated on: ${currentDate}`, pageWidth / 2, 55, { align: 'center' });
          
          // Capture charts
          const charts = document.querySelectorAll('.chart-box');
          let currentY = 70;
          
          Promise.all(Array.from(charts).map((chart, index) => {
              return html2canvas(chart, {
                  scale: 2,
                  useCORS: true,
                  allowTaint: true,
                  backgroundColor: '#ffffff'
              }).then(canvas => {
                  return { canvas, index, chart };
              });
          })).then(results => {
              results.forEach(({ canvas, index, chart }) => {
                  const imgData = canvas.toDataURL('image/png');
                  const imgWidth = contentWidth;
                  const imgHeight = (canvas.height * imgWidth) / canvas.width;
                  
                  // Check if we need a new page
                  if (currentY + imgHeight > pageHeight - margin) {
                      pdf.addPage();
                      currentY = margin;
                  }
                  
                  // Add chart image
                  pdf.addImage(imgData, 'PNG', margin, currentY, imgWidth, imgHeight);
                  currentY += imgHeight + 10;
                  
                  // Add chart title
                  const chartTitle = chart.querySelector('h2').textContent;
                  pdf.setFontSize(14);
                  pdf.setFont('helvetica', 'bold');
                  pdf.text(chartTitle, pageWidth / 2, currentY - 5, { align: 'center' });
              });
              
              // Add summary statistics
              pdf.addPage();
              pdf.setFontSize(16);
              pdf.setFont('helvetica', 'bold');
              pdf.text('Summary Statistics', pageWidth / 2, 30, { align: 'center' });
              
              pdf.setFontSize(12);
              pdf.setFont('helvetica', 'normal');
              let yPos = 50;
              
              const totalRecords = chartData.reduce((sum, count) => sum + count, 0);
              const maxRecords = Math.max(...chartData);
              const minRecords = Math.min(...chartData.filter(count => count > 0));
              const avgRecords = totalRecords / chartData.filter(count => count > 0).length;
              
              pdf.text(`Total Records: ${totalRecords}`, margin, yPos);
              yPos += 10;
              pdf.text(`Maximum Records: ${maxRecords}`, margin, yPos);
              yPos += 10;
              pdf.text(`Minimum Records: ${minRecords || 0}`, margin, yPos);
              yPos += 10;
              pdf.text(`Average Records: ${avgRecords.toFixed(2)}`, margin, yPos);
              yPos += 10;
              
              if (selectedMonth > 0) {
                  const monthNames = ['', 'January', 'February', 'March', 'April', 'May', 'June', 
                                     'July', 'August', 'September', 'October', 'November', 'December'];
                  pdf.text(`Period: ${monthNames[selectedMonth]} ${selectedYear}`, margin, yPos);
              } else {
                  pdf.text(`Period: ${selectedYear}`, margin, yPos);
              }
              
              // Save the PDF
              const fileName = `lkk_records_${selectedYear}${selectedMonth > 0 ? '_' + selectedMonth.toString().padStart(2, '0') : ''}.pdf`;
              pdf.save(fileName);
              
              // Reset button
              printBtn.innerHTML = originalText;
              printBtn.disabled = false;
          }).catch(error => {
              console.error('Error generating PDF:', error);
              alert('Error generating PDF. Please try again.');
              printBtn.innerHTML = originalText;
              printBtn.disabled = false;
          });
      }
    </script>
    <!-- Core JS Files -->
    <script src="../assets/js/core/jquery-3.7.1.min.js"></script>
    <script src="../assets/js/core/popper.min.js"></script>
    <script src="../assets/js/core/bootstrap.min.js"></script>
    <!-- jQuery Scrollbar -->
    <script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
    <!-- Kaiadmin JS -->
    <script src="../assets/js/kaiadmin.min.js"></script>
    <!-- Kaiadmin DEMO methods, don't include it in your project! -->
    <script src="../assets/js/setting-demo2.js"></script>
  </body>
</html>
